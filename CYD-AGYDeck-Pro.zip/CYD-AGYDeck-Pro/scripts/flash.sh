#!/usr/bin/env bash
# One-Click Firmware Flasher for CYD AGYDeck Pro

PORT="/dev/ttyUSB0"
BAUD="460800"
BIN_PATH="$(dirname "$0")/../bin/CYD_StreamDeck_SD.bin"

echo "=== CYD AGYDeck Pro One-Click Flasher ==="
if [ ! -e "$PORT" ]; then
    echo "Error: Serial port $PORT not found!"
    echo "Please plug in your CYD board via USB."
    exit 1
fi

echo "Flashing binary $BIN_PATH to $PORT at $BAUD baud..."
python3 -m esptool --port "$PORT" --baud "$BAUD" write_flash -z 0x10000 "$BIN_PATH"

echo "Flash complete! CYD board reset."
