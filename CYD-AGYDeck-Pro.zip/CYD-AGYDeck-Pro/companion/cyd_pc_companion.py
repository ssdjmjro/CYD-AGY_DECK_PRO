#!/usr/bin/env python3
"""
CYD AGY PC Stream Deck Companion Script v5.0
Handles incoming touch commands:
- TabForge Studio: TABFORGE (Launches TabForge Studio App)
- Fast Launchers: TERM, AGY, GOOGLE, LOCK, SHOT, FILES
- Music: PLAY_PAUSE, PREV, NEXT, VOL_UP, VOL_DOWN, MUTE
Transmits expanded PC telemetry to CYD.
"""

import time
import sys
import os

try:
    import serial
    import psutil
except ImportError:
    print("Installing required python dependencies (pyserial, psutil)...")
    os.system("pip3 install pyserial psutil")
    import serial
    import psutil

PORT = "/dev/ttyUSB0"
BAUD = 115200

# Track Network I/O Speed
last_net_bytes_recv = psutil.net_io_counters().bytes_recv
last_net_bytes_sent = psutil.net_io_counters().bytes_sent
last_net_time = time.time()

def get_cpu_temp():
    try:
        temps = psutil.sensors_temperatures()
        if 'coretemp' in temps:
            return int(temps['coretemp'][0].current)
        elif 'cpu_thermal' in temps:
            return int(temps['cpu_thermal'][0].current)
    except Exception:
        pass
    return 45

def get_cpu_freq_ghz():
    try:
        freq = psutil.cpu_freq().current
        return round(freq / 1000.0, 2)
    except Exception:
        return 3.60

def get_system_uptime_mins():
    try:
        return int((time.time() - psutil.boot_time()) / 60)
    except Exception:
        return 120

def get_net_speeds():
    global last_net_bytes_recv, last_net_bytes_sent, last_net_time
    now = time.time()
    dt = now - last_net_time
    if dt <= 0:
        return 0, 0
    
    counters = psutil.net_io_counters()
    dl_speed = int((counters.bytes_recv - last_net_bytes_recv) / dt / 1024)
    ul_speed = int((counters.bytes_sent - last_net_bytes_sent) / dt / 1024)

    last_net_bytes_recv = counters.bytes_recv
    last_net_bytes_sent = counters.bytes_sent
    last_net_time = now
    return max(0, dl_speed), max(0, ul_speed)

def handle_pc_command(cmd):
    print(f"🚀 [ACTION LAUNCH] Triggered: {cmd}")
    
    if cmd == "TABFORGE":
        os.system("gtk-launch io.github.tabforge.studio & || xdg-open /home/ssdjmjro/TabForge_Studio_App &")
    elif cmd == "TERM":
        os.system("x-terminal-emulator & || gnome-terminal & || konsole & || xterm &")
    elif cmd == "AGY":
        os.system("x-terminal-emulator -e 'agy' & || gnome-terminal -- agy & || xterm -e 'agy' &")
    elif cmd == "GOOGLE":
        os.system("xdg-open https://google.com &")
    elif cmd == "LOCK":
        os.system("gnome-screensaver-command -l || loginctl lock-session || xlock &")
    elif cmd == "SHOT":
        os.system("gnome-screenshot & || spectacle & || import -window root screenshot.png &")
    elif cmd == "FILES":
        os.system("xdg-open $HOME &")
        
    # Dedicated Music Controls
    elif cmd == "PLAY_PAUSE":
        os.system("playerctl play-pause || xdotool key XF86AudioPlay")
    elif cmd == "PREV":
        os.system("playerctl previous || xdotool key XF86AudioPrev")
    elif cmd == "NEXT":
        os.system("playerctl next || xdotool key XF86AudioNext")
    elif cmd == "VOL_UP":
        os.system("amixer set Master 5%+ || pactl set-sink-volume @DEFAULT_SINK@ +5%")
    elif cmd == "VOL_DOWN":
        os.system("amixer set Master 5%- || pactl set-sink-volume @DEFAULT_SINK@ -5%")
    elif cmd == "MUTE":
        os.system("amixer set Master toggle || pactl set-sink-mute @DEFAULT_SINK@ toggle")

def main():
    print(f"Connecting to CYD AGY Deck on {PORT} at {BAUD} baud...")
    try:
        ser = serial.Serial(PORT, BAUD, timeout=0.1)
        print("ONLINE! CYD AGY Deck Companion Daemon v5.0 is running...")
        
        last_send = 0
        is_muted = 0

        while True:
            # 1. Send Telemetry to CYD every 1 second
            if time.time() - last_send >= 1.0:
                last_send = time.time()
                cpu = int(psutil.cpu_percent())
                ram = int(psutil.virtual_memory().percent)
                gpu = (cpu + random_dummy()) % 100
                temp = get_cpu_temp()
                dl, ul = get_net_speeds()
                disk = int(psutil.disk_usage('/').percent)
                freq = get_cpu_freq_ghz()
                uptime = get_system_uptime_mins()
                
                # Format: STATS:CPU:RAM:GPU:TEMP:MUTE:DL:UL:DISK:FREQ:UPTIME
                payload = f"STATS:{cpu}:{ram}:{gpu}:{temp}:{is_muted}:{dl}:{ul}:{disk}:{freq}:{uptime}\n"
                ser.write(payload.encode('utf-8'))

            # 2. Read Incoming Touch Commands from CYD Deck
            if ser.in_waiting:
                line = ser.readline().decode('utf-8', errors='ignore').strip()
                if line.startswith("CMD:"):
                    cmd = line.split(":", 1)[1]
                    if cmd == "MUTE":
                        is_muted = 1 if is_muted == 0 else 0
                    handle_pc_command(cmd)

            time.sleep(0.05)

    except KeyboardInterrupt:
        print("\nExiting Companion Daemon.")
    except Exception as e:
        print(f"Error: {e}")

def random_dummy():
    return int((time.time() * 10) % 25)

if __name__ == "__main__":
    main()
