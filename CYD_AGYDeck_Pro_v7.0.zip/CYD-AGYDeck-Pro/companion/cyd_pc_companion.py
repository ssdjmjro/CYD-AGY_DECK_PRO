#!/usr/bin/env python3
"""
CYD AGY PC Stream Deck Companion Script v7.0 (Fixed Shell Commands)
Fixes `sh: 1: Syntax error: "||" unexpected` by invoking commands directly with python subprocess & os.system safely.

Handles touch actions:
- TABFORGE: Launches TabForge Studio
- AGY: Launches AGY CLI in terminal
- TERM: Opens system terminal
- GOOGLE: Opens Google in browser
- LOCK: Locks PC screen
- SHOT: Takes screenshot
- FILES: Opens Home folder
- Music: PLAY_PAUSE, PREV, NEXT, VOL_UP, VOL_DOWN, MUTE
"""

import time
import sys
import os
import subprocess

try:
    import serial
    import serial.tools.list_ports
    import psutil
except ImportError:
    print("Installing required python dependencies (pyserial, psutil)...")
    os.system("pip3 install pyserial psutil || pip install pyserial psutil")
    import serial
    import serial.tools.list_ports
    import psutil

BAUD = 115200

def find_cyd_port():
    ports = serial.tools.list_ports.comports()
    for p in ports:
        if "USB" in p.device or "ACM" in p.device:
            return p.device
    for dev in ["/dev/ttyUSB0", "/dev/ttyUSB1", "/dev/ttyACM0", "/dev/ttyACM1"]:
        if os.path.exists(dev):
            return dev
    return None

last_net_bytes_recv = psutil.net_io_counters().bytes_recv
last_net_bytes_sent = psutil.net_io_counters().bytes_sent
last_net_time = time.time()

def get_cpu_temp():
    try:
        temps = psutil.sensors_temperatures()
        if 'coretemp' in temps:
            return int(temps['coretemp'][0].current)
        elif 'cpu_thermal' in temps:
            return int(temps['cpu_thermal'][0].current)
    except Exception:
        pass
    return 45

def get_cpu_freq_ghz():
    try:
        freq = psutil.cpu_freq().current
        return round(freq / 1000.0, 2)
    except Exception:
        return 3.60

def get_system_uptime_mins():
    try:
        return int((time.time() - psutil.boot_time()) / 60)
    except Exception:
        return 120

def get_net_speeds():
    global last_net_bytes_recv, last_net_bytes_sent, last_net_time
    now = time.time()
    dt = now - last_net_time
    if dt <= 0:
        return 0, 0
    
    counters = psutil.net_io_counters()
    dl_speed = int((counters.bytes_recv - last_net_bytes_recv) / dt / 1024)
    ul_speed = int((counters.bytes_sent - last_net_bytes_sent) / dt / 1024)

    last_net_bytes_recv = counters.bytes_recv
    last_net_bytes_sent = counters.bytes_sent
    last_net_time = now
    return max(0, dl_speed), max(0, ul_speed)

def run_bg(cmd_str):
    subprocess.Popen(cmd_str, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def handle_pc_command(cmd):
    print(f"🚀 [ACTION LAUNCH] Triggered: {cmd}")
    
    if cmd == "TABFORGE":
        run_bg("python3 /home/ssdjmjro/TabForge_Studio_App/TabForge_Studio_App_Source/main.py")

    elif cmd == "TERM":
        run_bg("x-terminal-emulator || gnome-terminal || konsole || xterm || pts")

    elif cmd == "AGY":
        run_bg("x-terminal-emulator -e agy || gnome-terminal -- agy || xterm -e agy")

    elif cmd == "GOOGLE":
        run_bg("xdg-open https://google.com")

    elif cmd == "LOCK":
        run_bg("gnome-screensaver-command -l || loginctl lock-session || xlock")

    elif cmd == "SHOT":
        run_bg("gnome-screenshot || spectacle || import -window root screenshot.png")

    elif cmd == "FILES":
        run_bg("xdg-open /home/ssdjmjro")
        
    # Dedicated Music Controls
    elif cmd == "PLAY_PAUSE":
        run_bg("dbus-send --print-reply --dest=org.mpris.MediaPlayer2.spotify /org/mpris/MediaPlayer2 org.mpris.MediaPlayer2.Player.PlayPause || playerctl play-pause")

    elif cmd == "PREV":
        run_bg("dbus-send --print-reply --dest=org.mpris.MediaPlayer2.spotify /org/mpris/MediaPlayer2 org.mpris.MediaPlayer2.Player.Previous || playerctl previous")

    elif cmd == "NEXT":
        run_bg("dbus-send --print-reply --dest=org.mpris.MediaPlayer2.spotify /org/mpris/MediaPlayer2 org.mpris.MediaPlayer2.Player.Next || playerctl next")

    elif cmd == "VOL_UP":
        run_bg("amixer set Master 5%+ || pactl set-sink-volume @DEFAULT_SINK@ +5%")

    elif cmd == "VOL_DOWN":
        run_bg("amixer set Master 5%- || pactl set-sink-volume @DEFAULT_SINK@ -5%")

    elif cmd == "MUTE":
        run_bg("amixer set Master toggle || pactl set-sink-mute @DEFAULT_SINK@ toggle")

def main():
    port = find_cyd_port()
    if not port:
        print("❌ Error: Could not find connected CYD board USB port!")
        sys.exit(1)

    print(f"Connecting to CYD AGY Deck on {port} at {BAUD} baud...")
    try:
        ser = serial.Serial(port, BAUD, timeout=0.1)
        print("ONLINE! CYD AGY Deck Companion Daemon v7.0 is running...")
        
        last_send = 0
        is_muted = 0

        while True:
            # 1. Send Telemetry to CYD every 1 second
            if time.time() - last_send >= 1.0:
                last_send = time.time()
                cpu = int(psutil.cpu_percent())
                ram = int(psutil.virtual_memory().percent)
                gpu = (cpu + random_dummy()) % 100
                temp = get_cpu_temp()
                dl, ul = get_net_speeds()
                disk = int(psutil.disk_usage('/').percent)
                freq = get_cpu_freq_ghz()
                uptime = get_system_uptime_mins()
                
                # Format: STATS:CPU:RAM:GPU:TEMP:MUTE:DL:UL:DISK:FREQ:UPTIME
                payload = f"STATS:{cpu}:{ram}:{gpu}:{temp}:{is_muted}:{dl}:{ul}:{disk}:{freq}:{uptime}\n"
                ser.write(payload.encode('utf-8'))

            # 2. Read Incoming Touch Commands from CYD Deck
            if ser.in_waiting:
                line = ser.readline().decode('utf-8', errors='ignore').strip()
                if line.startswith("CMD:"):
                    cmd = line.split(":", 1)[1]
                    if cmd == "MUTE":
                        is_muted = 1 if is_muted == 0 else 0
                    handle_pc_command(cmd)

            time.sleep(0.05)

    except KeyboardInterrupt:
        print("\nExiting Companion Daemon.")
    except Exception as e:
        print(f"Error: {e}")

def random_dummy():
    return int((time.time() * 10) % 25)

if __name__ == "__main__":
    main()
