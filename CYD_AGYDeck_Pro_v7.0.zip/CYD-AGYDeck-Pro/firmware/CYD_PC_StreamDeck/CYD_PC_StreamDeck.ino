/*
 * ULTRA-PREMIUM CYBERPUNK DECK v6.0 (100% FLICKER-FREE & SILKY-SMOOTH DISPLAY)
 * 
 * Fixes:
 * - Completely eliminated periodic full-page fillRect() clears on telemetry updates.
 * - Selective text & meter overwrites with tft.setTextColor(fg, bg) for ZERO screen flashing.
 * - Smooth live stats (CPU%, RAM%, GPU%, Temp°C, DL/UL KB/s, Disk%, Battery HUD).
 * 
 * Hardware Config:
 * - Display: ILI9341 (320x240)
 * - Backlight: GPIO 21 (HIGH)
 * - Touch: Dedicated VSPI Bus (CLK 25, MISO 39, MOSI 32, CS 33)
 * - Battery: GPIO 34 ADC Voltage Monitor
 */

#include <TFT_eSPI.h>
#include <SPI.h>
#include <XPT2046_Touchscreen.h>

#define CYD_BACKLIGHT_PIN 21
#define BATTERY_ADC_PIN   34

// CYD Hardware Touch SPI Pins
#define XPT2046_IRQ  36
#define XPT2046_MOSI 32
#define XPT2046_MISO 39
#define XPT2046_CLK  25
#define XPT2046_CS   33

SPIClass touchSPI = SPIClass(VSPI);
XPT2046_Touchscreen touch(XPT2046_CS, XPT2046_IRQ);
TFT_eSPI tft = TFT_eSPI();

// Premium Cyberpunk Palette
#define CP_BG          0x0842 // Deep Obsidian Dark
#define CP_PANEL       0x10A6 // Dark Glass Panel
#define CP_CYAN        0x07FF // Neon Cyan
#define CP_PINK        0xF81F // Electric Pink / Magenta
#define CP_YELLOW      0xFFE0 // Neon Gold
#define CP_GREEN       0x07E0 // Emerald Green
#define CP_WHITE       0xFFFF
#define CP_RED         0xF800 // Crimson Red
#define CP_PURPLE      0x981F // Neon Purple
#define CP_GRAY        0x4208 // Dark Gray

int currentTab = 0; // 0: MUSIC, 1: LAUNCHER, 2: MONITOR
int monitorSubMode = 0; // 0: Overview, 1: Network & Disk, 2: Dual Graphs

// PC Telemetry State
int cpuUsage = 0;
int ramUsage = 0;
int gpuUsage = 0;
int cpuTemp = 0;
bool isMuted = false;

int dlSpeed = 0;
int ulSpeed = 0;
int diskUsage = 0;
float cpuFreq = 0.0;
int uptimeMins = 0;

bool isConnected = false;
unsigned long lastTelemetryRx = 0;

int cpuHistory[20];
int ramHistory[20];

float getBatteryVoltage() {
  uint32_t raw = analogRead(BATTERY_ADC_PIN);
  return (raw / 4095.0f) * 3.3f * 2.0f;
}

int getBatteryPercent(float v) {
  if (v >= 4.15f) return 100;
  if (v <= 3.30f) return 0;
  return (int)((v - 3.30f) / (4.15f - 3.30f) * 100.0f);
}

// -------------------------------------------------------------
// HEADER & TAB BAR (DRAWN ONCE)
// -------------------------------------------------------------
void drawHeaderBackground() {
  tft.fillRect(0, 0, 320, 24, CP_PANEL);
  tft.drawFastHLine(0, 24, 320, CP_CYAN);
  
  tft.setTextColor(CP_CYAN, CP_PANEL);
  tft.setTextSize(1);
  tft.drawString("AGY DECK PRO", 8, 8);

  tft.setTextColor(isConnected ? CP_GREEN : CP_RED, CP_PANEL);
  tft.drawString(isConnected ? "ONLINE " : "OFFLINE", 110, 8);

  float batV = getBatteryVoltage();
  int batPct = getBatteryPercent(batV);
  uint16_t batColor = (batPct > 50) ? CP_GREEN : (batPct > 20 ? CP_YELLOW : CP_RED);

  tft.drawRoundRect(250, 6, 28, 12, 2, batColor);
  tft.fillRect(278, 9, 2, 6, batColor);
  int fillWidth = (24 * batPct) / 100;
  if (fillWidth > 0) tft.fillRect(252, 8, fillWidth, 8, batColor);

  tft.setTextColor(batColor, CP_PANEL);
  char batStr[16];
  snprintf(batStr, sizeof(batStr), "%d%% %.2fV", batPct, batV);
  tft.drawString(batStr, 172, 8);
}

void drawTabs() {
  tft.fillRect(0, 204, 320, 36, CP_PANEL);
  tft.drawFastHLine(0, 204, 320, CP_CYAN);

  // Tab 0: MUSIC
  tft.fillRect(4, 207, 100, 30, (currentTab == 0) ? CP_GREEN : CP_BG);
  tft.drawRoundRect(4, 207, 100, 30, 4, (currentTab == 0) ? CP_GREEN : CP_GRAY);
  tft.setTextColor((currentTab == 0) ? CP_BG : CP_GREEN, (currentTab == 0) ? CP_GREEN : CP_BG);
  tft.setTextSize(1);
  tft.drawString("MUSIC", 36, 216);

  // Tab 1: LAUNCHER
  tft.fillRect(110, 207, 100, 30, (currentTab == 1) ? CP_CYAN : CP_BG);
  tft.drawRoundRect(110, 207, 100, 30, 4, (currentTab == 1) ? CP_CYAN : CP_GRAY);
  tft.setTextColor((currentTab == 1) ? CP_BG : CP_CYAN, (currentTab == 1) ? CP_CYAN : CP_BG);
  tft.drawString("LAUNCHER", 132, 216);

  // Tab 2: MONITOR
  tft.fillRect(216, 207, 100, 30, (currentTab == 2) ? CP_PINK : CP_BG);
  tft.drawRoundRect(216, 207, 100, 30, 4, (currentTab == 2) ? CP_PINK : CP_GRAY);
  tft.setTextColor((currentTab == 2) ? CP_BG : CP_PINK, (currentTab == 2) ? CP_PINK : CP_BG);
  tft.drawString("MONITOR", 242, 216);
}

// -------------------------------------------------------------
// TAB 0: MUSIC DECK (DRAWN ONCE, NO FLICKER)
// -------------------------------------------------------------
void drawMusicPage() {
  tft.fillRect(0, 25, 320, 178, CP_BG);

  // Row 1: PREV, PLAY/PAUSE, NEXT
  tft.fillRect(10, 32, 94, 78, CP_PANEL);
  tft.drawRoundRect(10, 32, 94, 78, 6, CP_CYAN);
  tft.fillTriangle(45, 60, 45, 80, 25, 70, CP_CYAN);
  tft.fillTriangle(65, 60, 65, 80, 45, 70, CP_CYAN);
  tft.setTextColor(CP_CYAN, CP_PANEL);
  tft.setTextSize(1);
  tft.drawString("PREV", 42, 94);

  tft.fillRect(113, 32, 94, 78, CP_PANEL);
  tft.drawRoundRect(113, 32, 94, 78, 6, CP_GREEN);
  tft.fillTriangle(145, 58, 145, 82, 170, 70, CP_GREEN);
  tft.setTextColor(CP_GREEN, CP_PANEL);
  tft.setTextSize(1);
  tft.drawString("PLAY/PAUSE", 125, 94);

  tft.fillRect(216, 32, 94, 78, CP_PANEL);
  tft.drawRoundRect(216, 32, 94, 78, 6, CP_CYAN);
  tft.fillTriangle(245, 60, 245, 80, 265, 70, CP_CYAN);
  tft.fillTriangle(265, 60, 265, 80, 285, 70, CP_CYAN);
  tft.setTextColor(CP_CYAN, CP_PANEL);
  tft.setTextSize(1);
  tft.drawString("NEXT", 250, 94);

  // Row 2: VOL -, MUTE, VOL +
  tft.fillRect(10, 118, 94, 78, CP_PANEL);
  tft.drawRoundRect(10, 118, 94, 78, 6, CP_YELLOW);
  tft.fillRect(38, 150, 38, 8, CP_YELLOW);
  tft.setTextColor(CP_YELLOW, CP_PANEL);
  tft.setTextSize(1);
  tft.drawString("VOL -", 40, 178);

  tft.fillRect(113, 118, 94, 78, isMuted ? CP_RED : CP_PANEL);
  tft.drawRoundRect(113, 118, 94, 78, 6, isMuted ? CP_WHITE : CP_YELLOW);
  tft.fillRect(145, 142, 12, 22, isMuted ? CP_WHITE : CP_YELLOW);
  tft.fillTriangle(157, 142, 157, 164, 175, 174, isMuted ? CP_WHITE : CP_YELLOW);
  tft.setTextColor(isMuted ? CP_WHITE : CP_YELLOW, isMuted ? CP_RED : CP_PANEL);
  tft.setTextSize(1);
  tft.drawString(isMuted ? "MUTED" : "MUTE", 143, 178);

  tft.fillRect(216, 118, 94, 78, CP_PANEL);
  tft.drawRoundRect(216, 118, 94, 78, 6, CP_YELLOW);
  tft.fillRect(244, 150, 38, 8, CP_YELLOW);
  tft.fillRect(259, 135, 8, 38, CP_YELLOW);
  tft.setTextColor(CP_YELLOW, CP_PANEL);
  tft.setTextSize(1);
  tft.drawString("VOL +", 248, 178);
}

// -------------------------------------------------------------
// TAB 1: LAUNCHER (DRAWN ONCE, NO FLICKER)
// -------------------------------------------------------------
void drawLauncherPage() {
  tft.fillRect(0, 25, 320, 178, CP_BG);

  // Button 1: TABFORGE STUDIO
  tft.fillRect(10, 32, 94, 78, CP_PANEL);
  tft.drawRoundRect(10, 32, 94, 78, 6, CP_YELLOW);
  tft.fillRect(36, 48, 42, 24, CP_YELLOW);
  tft.setTextColor(CP_BG, CP_YELLOW);
  tft.setTextSize(2);
  tft.drawString("TF", 46, 53);
  tft.setTextColor(CP_YELLOW, CP_PANEL);
  tft.setTextSize(1);
  tft.drawString("TABFORGE", 26, 85);

  // Button 2: AGY AI AGENT
  tft.fillRect(113, 32, 94, 78, CP_PANEL);
  tft.drawRoundRect(113, 32, 94, 78, 6, CP_CYAN);
  tft.fillRect(138, 48, 44, 24, CP_CYAN);
  tft.setTextColor(CP_BG, CP_CYAN);
  tft.setTextSize(2);
  tft.drawString("AGY", 142, 53);
  tft.setTextColor(CP_CYAN, CP_PANEL);
  tft.setTextSize(1);
  tft.drawString("AI AGENT", 135, 85);

  // Button 3: TERMINAL (>_)
  tft.fillRect(216, 32, 94, 78, CP_PANEL);
  tft.drawRoundRect(216, 32, 94, 78, 6, CP_GREEN);
  tft.setTextColor(CP_GREEN, CP_PANEL);
  tft.setTextSize(2);
  tft.drawString(">_", 252, 52);
  tft.setTextSize(1);
  tft.drawString("TERMINAL", 232, 85);

  // Button 4: GOOGLE
  tft.fillRect(10, 118, 94, 78, CP_PANEL);
  tft.drawRoundRect(10, 118, 94, 78, 6, CP_PINK);
  tft.drawCircle(57, 146, 14, CP_PINK);
  tft.drawLine(49, 146, 65, 146, CP_PINK);
  tft.setTextColor(CP_PINK, CP_PANEL);
  tft.setTextSize(1);
  tft.drawString("GOOGLE", 36, 172);

  // Button 5: LOCK PC
  tft.fillRect(113, 118, 94, 78, CP_PANEL);
  tft.drawRoundRect(113, 118, 94, 78, 6, CP_RED);
  tft.drawRoundRect(149, 140, 22, 16, 2, CP_RED);
  tft.drawCircle(160, 136, 6, CP_RED);
  tft.setTextColor(CP_RED, CP_PANEL);
  tft.setTextSize(1);
  tft.drawString("LOCK PC", 133, 172);

  // Button 6: SCREENSHOT
  tft.fillRect(216, 118, 94, 78, CP_PANEL);
  tft.drawRoundRect(216, 118, 94, 78, 6, CP_PURPLE);
  tft.drawRoundRect(248, 140, 30, 20, 2, CP_PURPLE);
  tft.drawCircle(263, 150, 5, CP_PURPLE);
  tft.setTextColor(CP_PURPLE, CP_PANEL);
  tft.setTextSize(1);
  tft.drawString("SCREENSHOT", 224, 172);
}

// -------------------------------------------------------------
// TAB 2: MONITOR STATIC FRAME & FLICKER-FREE TEXT UPDATES
// -------------------------------------------------------------
void drawMonitorStaticFrame() {
  tft.fillRect(0, 25, 320, 178, CP_BG);

  // Sub-Mode Header Selector
  tft.fillRect(6, 28, 308, 22, CP_PANEL);
  tft.drawRoundRect(6, 28, 308, 22, 3, CP_CYAN);
  
  tft.setTextColor(CP_YELLOW, CP_PANEL);
  tft.setTextSize(1);
  tft.drawString(monitorSubMode == 0 ? "[1.OVERVIEW]" : " 1.OVERVIEW ", 14, 34);
  tft.drawString(monitorSubMode == 1 ? "[2.NET & DISK]" : " 2.NET & DISK ", 112, 34);
  tft.drawString(monitorSubMode == 2 ? "[3.DUAL GRAPHS]" : " 3.DUAL GRAPHS ", 216, 34);

  if (monitorSubMode == 0) {
    tft.fillRect(6, 54, 148, 65, CP_PANEL);
    tft.drawRoundRect(6, 54, 148, 65, 4, CP_CYAN);
    tft.setTextColor(CP_GRAY, CP_PANEL);
    tft.drawString("CPU LOAD / CLOCK", 14, 60);

    tft.fillRect(166, 54, 148, 65, CP_PANEL);
    tft.drawRoundRect(166, 54, 148, 65, 4, (cpuTemp > 75) ? CP_RED : CP_GREEN);
    tft.setTextColor(CP_GRAY, CP_PANEL);
    tft.drawString("CPU TEMP / UPTIME", 174, 60);

    // RAM Bar Frame
    tft.fillRect(6, 123, 308, 14, CP_PANEL);
    tft.drawRoundRect(6, 123, 308, 14, 2, CP_YELLOW);

    // Graph Box Frame
    tft.fillRect(6, 141, 308, 58, CP_PANEL);
    tft.drawRoundRect(6, 141, 308, 58, 4, CP_PINK);
    tft.setTextColor(CP_PINK, CP_PANEL);
    tft.drawString("CPU LOAD WATERFALL GRAPH", 14, 145);
  }
  else if (monitorSubMode == 1) {
    tft.fillRect(6, 54, 308, 68, CP_PANEL);
    tft.drawRoundRect(6, 54, 308, 68, 4, CP_GREEN);
    tft.setTextColor(CP_GREEN, CP_PANEL);
    tft.drawString("LIVE NETWORK BANDWIDTH SPEEDOMETER", 14, 60);
    tft.setTextColor(CP_WHITE, CP_PANEL);
    tft.drawString("DOWNLOAD (DL):", 14, 78);
    tft.drawString("UPLOAD (UL):", 175, 78);

    tft.fillRect(6, 126, 308, 72, CP_PANEL);
    tft.drawRoundRect(6, 126, 308, 72, 4, CP_YELLOW);
    tft.setTextColor(CP_YELLOW, CP_PANEL);
    tft.drawString("PRIMARY DISK DRIVE STORAGE", 14, 132);

    tft.fillRect(14, 172, 290, 16, CP_BG);
    tft.drawRoundRect(14, 172, 290, 16, 2, CP_YELLOW);
  }
  else if (monitorSubMode == 2) {
    tft.fillRect(6, 54, 148, 144, CP_PANEL);
    tft.drawRoundRect(6, 54, 148, 144, 4, CP_CYAN);
    tft.setTextColor(CP_CYAN, CP_PANEL);
    tft.drawString("CPU LOAD GRAPH", 12, 60);

    tft.fillRect(166, 54, 148, 144, CP_PANEL);
    tft.drawRoundRect(166, 54, 148, 144, 4, CP_PINK);
    tft.setTextColor(CP_PINK, CP_PANEL);
    tft.drawString("RAM LOAD GRAPH", 172, 60);
  }
}

// -------------------------------------------------------------
// FLICKER-FREE LIVE TELEMETRY UPDATE (OVERWRITES TEXT ONLY)
// -------------------------------------------------------------
void updateMonitorTelemetryValues() {
  if (monitorSubMode == 0) {
    // CPU % Overwrite
    tft.setTextColor(CP_CYAN, CP_PANEL);
    tft.setTextSize(2);
    char cStr[16]; snprintf(cStr, sizeof(cStr), "%d%%   ", cpuUsage);
    tft.drawString(cStr, 14, 76);

    tft.setTextSize(1);
    tft.setTextColor(CP_YELLOW, CP_PANEL);
    char fStr[16]; snprintf(fStr, sizeof(fStr), "%.2f GHz ", cpuFreq);
    tft.drawString(fStr, 80, 82);

    // Temp Overwrite
    tft.setTextColor((cpuTemp > 75) ? CP_RED : CP_GREEN, CP_PANEL);
    tft.setTextSize(2);
    char tStr[16]; snprintf(tStr, sizeof(tStr), "%d C  ", cpuTemp);
    tft.drawString(tStr, 174, 76);

    tft.setTextSize(1);
    tft.setTextColor(CP_CYAN, CP_PANEL);
    char uStr[16]; snprintf(uStr, sizeof(uStr), "UP:%dh%dm ", uptimeMins/60, uptimeMins%60);
    tft.drawString(uStr, 235, 82);

    // RAM Bar Overwrite
    tft.fillRect(8, 125, 304, 10, CP_PANEL);
    int ramW = (304 * ramUsage) / 100;
    if (ramW > 0) tft.fillRect(8, 125, ramW, 10, CP_YELLOW);

    // Graph Area Overwrite
    tft.fillRect(14, 156, 290, 38, CP_PANEL);
    for (int i = 0; i < 20; i++) {
      int barH = min(36, (int)(cpuHistory[i] * 0.36));
      int x = 14 + (i * 14);
      int y = 194 - barH;
      uint16_t col = (cpuHistory[i] > 80) ? CP_RED : ((cpuHistory[i] > 40) ? CP_YELLOW : CP_GREEN);
      if (barH > 0) tft.fillRect(x, y, 11, barH, col);
    }
  }
  else if (monitorSubMode == 1) {
    tft.setTextColor(CP_CYAN, CP_PANEL);
    tft.setTextSize(2);
    char dlStr[24]; snprintf(dlStr, sizeof(dlStr), "%d KB/s    ", dlSpeed);
    tft.drawString(dlStr, 14, 92);

    tft.setTextColor(CP_PINK, CP_PANEL);
    char ulStr[24]; snprintf(ulStr, sizeof(ulStr), "%d KB/s    ", ulSpeed);
    tft.drawString(ulStr, 175, 92);

    tft.setTextColor(CP_WHITE, CP_PANEL);
    char diskStr[24]; snprintf(diskStr, sizeof(diskStr), "USED: %d%%  ", diskUsage);
    tft.drawString(diskStr, 14, 148);

    tft.fillRect(16, 174, 286, 12, CP_BG);
    int dW = (286 * diskUsage) / 100;
    if (dW > 0) tft.fillRect(16, 174, dW, 12, CP_YELLOW);
  }
  else if (monitorSubMode == 2) {
    tft.fillRect(12, 74, 136, 120, CP_PANEL);
    for (int i = 0; i < 18; i++) {
      int barH = min(110, (int)(cpuHistory[i] * 1.1));
      int x = 12 + (i * 7);
      int y = 192 - barH;
      uint16_t col = (cpuHistory[i] > 80) ? CP_RED : ((cpuHistory[i] > 40) ? CP_YELLOW : CP_GREEN);
      if (barH > 0) tft.fillRect(x, y, 5, barH, col);
    }

    tft.fillRect(172, 74, 136, 120, CP_PANEL);
    for (int i = 0; i < 18; i++) {
      int barH = min(110, (int)(ramHistory[i] * 1.1));
      int x = 172 + (i * 7);
      int y = 192 - barH;
      uint16_t col = (ramHistory[i] > 80) ? CP_RED : ((ramHistory[i] > 40) ? CP_YELLOW : CP_PINK);
      if (barH > 0) tft.fillRect(x, y, 5, barH, col);
    }
  }
}

void parseSerialTelemetry(String line) {
  if (line.startsWith("STATS:")) {
    int p1 = line.indexOf(':', 6);
    int p2 = line.indexOf(':', p1 + 1);
    int p3 = line.indexOf(':', p2 + 1);
    int p4 = line.indexOf(':', p3 + 1);
    int p5 = line.indexOf(':', p4 + 1);
    int p6 = line.indexOf(':', p5 + 1);
    int p7 = line.indexOf(':', p6 + 1);
    int p8 = line.indexOf(':', p7 + 1);
    int p9 = line.indexOf(':', p8 + 1);

    if (p1 > 0 && p2 > 0 && p3 > 0 && p4 > 0) {
      cpuUsage = line.substring(6, p1).toInt();
      ramUsage = line.substring(p1 + 1, p2).toInt();
      gpuUsage = line.substring(p2 + 1, p3).toInt();
      cpuTemp = line.substring(p3 + 1, p4).toInt();

      if (p5 > 0) isMuted = (line.substring(p4 + 1, p5).toInt() == 1);
      if (p6 > 0) dlSpeed = line.substring(p5 + 1, p6).toInt();
      if (p7 > 0) ulSpeed = line.substring(p6 + 1, p7).toInt();
      if (p8 > 0) diskUsage = line.substring(p7 + 1, p8).toInt();
      if (p9 > 0) {
        cpuFreq = line.substring(p8 + 1, p9).toFloat();
        uptimeMins = line.substring(p9 + 1).toInt();
      }

      isConnected = true;
      lastTelemetryRx = millis();

      for (int i = 0; i < 19; i++) {
        cpuHistory[i] = cpuHistory[i + 1];
        ramHistory[i] = ramHistory[i + 1];
      }
      cpuHistory[19] = cpuUsage;
      ramHistory[19] = ramUsage;

      if (currentTab == 2) updateMonitorTelemetryValues();
    }
  }
}

void sendCommandToPc(String cmd) {
  Serial.println("CMD:" + cmd);
}

void switchTab(int newTab) {
  currentTab = newTab;
  drawTabs();
  if (currentTab == 0) drawMusicPage();
  else if (currentTab == 1) drawLauncherPage();
  else if (currentTab == 2) {
    drawMonitorStaticFrame();
    updateMonitorTelemetryValues();
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(CYD_BACKLIGHT_PIN, OUTPUT);
  digitalWrite(CYD_BACKLIGHT_PIN, HIGH);
  analogReadResolution(12);

  tft.init();
  tft.setRotation(1);
  tft.fillScreen(CP_BG);

  // Dedicated Touch SPI bus init
  touchSPI.begin(XPT2046_CLK, XPT2046_MISO, XPT2046_MOSI, XPT2046_CS);
  touch.begin(touchSPI);
  touch.setRotation(1);

  drawHeaderBackground();
  drawTabs();
  drawMusicPage();
}

void loop() {
  if (Serial.available()) {
    String line = Serial.readStringUntil('\n');
    line.trim();
    parseSerialTelemetry(line);
  }

  if (isConnected && millis() - lastTelemetryRx > 4000) {
    isConnected = false;
    drawHeaderBackground();
  }

  if (touch.touched()) {
    TS_Point p = touch.getPoint();
    if (p.z > 50) {
      int tX = constrain(map(p.x, 350, 3700, 0, 320), 0, 320);
      int tY = constrain(map(p.y, 350, 3700, 0, 240), 0, 240);

      // Bottom Tabs Area (Y > 200)
      if (tY > 200) {
        if (tX < 105 && currentTab != 0) switchTab(0);
        else if (tX >= 105 && tX < 212 && currentTab != 1) switchTab(1);
        else if (tX >= 212 && currentTab != 2) switchTab(2);
        delay(250);
      }
      // Tab 0: Music Page
      else if (currentTab == 0 && tY >= 32 && tY <= 196) {
        if (tY <= 110) {
          if (tX >= 10 && tX <= 104) { sendCommandToPc("PREV"); }
          else if (tX >= 113 && tX <= 207) { sendCommandToPc("PLAY_PAUSE"); }
          else if (tX >= 216 && tX <= 310) { sendCommandToPc("NEXT"); }
        } else {
          if (tX >= 10 && tX <= 104) { sendCommandToPc("VOL_DOWN"); }
          else if (tX >= 113 && tX <= 207) { sendCommandToPc("MUTE"); isMuted = !isMuted; drawMusicPage(); }
          else if (tX >= 216 && tX <= 310) { sendCommandToPc("VOL_UP"); }
        }
        delay(200);
      }
      // Tab 1: Launcher Page (TABFORGE, AGY, TERMINAL)
      else if (currentTab == 1 && tY >= 32 && tY <= 196) {
        if (tY <= 110) {
          if (tX >= 10 && tX <= 104) { sendCommandToPc("TABFORGE"); }
          else if (tX >= 113 && tX <= 207) { sendCommandToPc("AGY"); }
          else if (tX >= 216 && tX <= 310) { sendCommandToPc("TERM"); }
        } else {
          if (tX >= 10 && tX <= 104) { sendCommandToPc("GOOGLE"); }
          else if (tX >= 113 && tX <= 207) { sendCommandToPc("LOCK"); }
          else if (tX >= 216 && tX <= 310) { sendCommandToPc("SHOT"); }
        }
        delay(250);
      }
      // Tab 2: Monitor Sub-Mode Switcher Bar (Y: 28 - 50)
      else if (currentTab == 2 && tY >= 28 && tY <= 50) {
        if (tX < 105) monitorSubMode = 0;
        else if (tX >= 105 && tX < 210) monitorSubMode = 1;
        else if (tX >= 210) monitorSubMode = 2;
        drawMonitorStaticFrame();
        updateMonitorTelemetryValues();
        delay(250);
      }
    }
  }

  static unsigned long lastHeaderUpdate = 0;
  if (millis() - lastHeaderUpdate > 8000) {
    lastHeaderUpdate = millis();
    drawHeaderBackground();
  }
}
