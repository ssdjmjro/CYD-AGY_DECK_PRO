/*
 * AGYDECK STUDIO PRO v8.0 (MATTE SLATE EXECUTIVE DESIGN SYSTEM FOR CYD)
 * 
 * Aesthetic Redesign:
 * - Replaced vibrant colors with an Executive Matte Slate / Gunmetal / Brushed Steel Dark Palette.
 * - Ultra-clean minimalist cards with subtle 1px slate borders and refined typography.
 * - Professional Studio Dashboard styling inspired by high-end pro audio & telemetry gear.
 * 
 * Features:
 * - Tab 1: [ 🎵 MUSIC ] Studio Audio Console (Play/Pause, Prev, Next, Vol+, Vol-, Mute)
 * - Tab 2: [ 🚀 LAUNCHER ] Executive App Launcher (TabForge Studio, AGY CLI, Terminal, Google, Lock PC, Files)
 * - Tab 3: [ 📊 MONITOR ] Pro Hardware Telemetry Hub (CPU GHz, Temp°C, RAM%, DL/UL Speedometer, Disk%)
 * - Live LiPo Battery Meter (GPIO 34)
 * - Dedicated Touch SPI Bus (CLK 25, MISO 39, MOSI 32, CS 33)
 */

#include <TFT_eSPI.h>
#include <SPI.h>
#include <XPT2046_Touchscreen.h>

#define CYD_BACKLIGHT_PIN 21
#define BATTERY_ADC_PIN   34

// CYD Hardware Touch SPI Pins
#define XPT2046_IRQ  36
#define XPT2046_MOSI 32
#define XPT2046_MISO 39
#define XPT2046_CLK  25
#define XPT2046_CS   33

SPIClass touchSPI = SPIClass(VSPI);
XPT2046_Touchscreen touch(XPT2046_CS, XPT2046_IRQ);
TFT_eSPI tft = TFT_eSPI();

// Executive Studio Color Palette
#define ST_BG          0x0842 // Deep Slate Black (#0B0D12)
#define ST_PANEL       0x18E5 // Dark Gunmetal Glass (#151820)
#define ST_BORDER      0x31C9 // Brushed Steel Border (#303644)
#define ST_ACCENT      0x053F // Studio Electric Blue (#00A4FF)
#define ST_WHITE       0xFFFF // Pure White
#define ST_MUTED       0x8C71 // Muted Platinum Gray (#8A92A0)
#define ST_GOLD        0xDCE0 // Subtle Gold (#D4A017)
#define ST_RED         0xD800 // Muted Crimson (#D00000)
#define ST_GREEN       0x0480 // Studio Emerald (#009040)
#define ST_ACTIVE_TAB  0x2129 // Slate Highlight

int currentTab = 0; // 0: MUSIC, 1: LAUNCHER, 2: MONITOR
int monitorSubMode = 0; // 0: Overview, 1: Network & Disk, 2: Dual Graphs

// PC Telemetry State
int cpuUsage = 0;
int ramUsage = 0;
int gpuUsage = 0;
int cpuTemp = 0;
bool isMuted = false;

int dlSpeed = 0;
int ulSpeed = 0;
int diskUsage = 0;
float cpuFreq = 0.0;
int uptimeMins = 0;

bool isConnected = false;
unsigned long lastTelemetryRx = 0;

int cpuHistory[20];
int ramHistory[20];

float getBatteryVoltage() {
  uint32_t raw = analogRead(BATTERY_ADC_PIN);
  return (raw / 4095.0f) * 3.3f * 2.0f;
}

int getBatteryPercent(float v) {
  if (v >= 4.15f) return 100;
  if (v <= 3.30f) return 0;
  return (int)((v - 3.30f) / (4.15f - 3.30f) * 100.0f);
}

// -------------------------------------------------------------
// HEADER & TAB BAR (EXECUTIVE MATTE SLATE DESIGN)
// -------------------------------------------------------------
void drawHeaderBackground() {
  tft.fillRect(0, 0, 320, 24, ST_PANEL);
  tft.drawFastHLine(0, 24, 320, ST_BORDER);
  
  tft.setTextColor(ST_WHITE, ST_PANEL);
  tft.setTextSize(1);
  tft.drawString("AGY STUDIO PRO", 8, 8);

  tft.setTextColor(isConnected ? ST_ACCENT : ST_RED, ST_PANEL);
  tft.drawString(isConnected ? "CONNECTED" : "DISCONNECTED", 110, 8);

  float batV = getBatteryVoltage();
  int batPct = getBatteryPercent(batV);
  uint16_t batColor = (batPct > 50) ? ST_ACCENT : (batPct > 20 ? ST_GOLD : ST_RED);

  tft.drawRoundRect(250, 6, 28, 12, 2, batColor);
  tft.fillRect(278, 9, 2, 6, batColor);
  int fillWidth = (24 * batPct) / 100;
  if (fillWidth > 0) tft.fillRect(252, 8, fillWidth, 8, batColor);

  tft.setTextColor(batColor, ST_PANEL);
  char batStr[16];
  snprintf(batStr, sizeof(batStr), "%d%% %.2fV", batPct, batV);
  tft.drawString(batStr, 172, 8);
}

void drawTabs() {
  tft.fillRect(0, 204, 320, 36, ST_PANEL);
  tft.drawFastHLine(0, 204, 320, ST_BORDER);

  // Tab 0: MUSIC
  tft.fillRect(4, 207, 100, 30, (currentTab == 0) ? ST_ACTIVE_TAB : ST_BG);
  tft.drawRoundRect(4, 207, 100, 30, 3, (currentTab == 0) ? ST_ACCENT : ST_BORDER);
  tft.setTextColor((currentTab == 0) ? ST_WHITE : ST_MUTED, (currentTab == 0) ? ST_ACTIVE_TAB : ST_BG);
  tft.setTextSize(1);
  tft.drawString("AUDIO", 36, 216);

  // Tab 1: LAUNCHER
  tft.fillRect(110, 207, 100, 30, (currentTab == 1) ? ST_ACTIVE_TAB : ST_BG);
  tft.drawRoundRect(110, 207, 100, 30, 3, (currentTab == 1) ? ST_ACCENT : ST_BORDER);
  tft.setTextColor((currentTab == 1) ? ST_WHITE : ST_MUTED, (currentTab == 1) ? ST_ACTIVE_TAB : ST_BG);
  tft.drawString("LAUNCHER", 132, 216);

  // Tab 2: MONITOR
  tft.fillRect(216, 207, 100, 30, (currentTab == 2) ? ST_ACTIVE_TAB : ST_BG);
  tft.drawRoundRect(216, 207, 100, 30, 3, (currentTab == 2) ? ST_ACCENT : ST_BORDER);
  tft.setTextColor((currentTab == 2) ? ST_WHITE : ST_MUTED, (currentTab == 2) ? ST_ACTIVE_TAB : ST_BG);
  tft.drawString("MONITOR", 242, 216);
}

// -------------------------------------------------------------
// TAB 0: STUDIO AUDIO CONSOLE
// -------------------------------------------------------------
void drawMusicPage() {
  tft.fillRect(0, 25, 320, 178, ST_BG);

  // Row 1: PREV, PLAY/PAUSE, NEXT
  tft.fillRect(10, 32, 94, 78, ST_PANEL);
  tft.drawRoundRect(10, 32, 94, 78, 4, ST_BORDER);
  tft.fillTriangle(45, 60, 45, 80, 25, 70, ST_WHITE);
  tft.fillTriangle(65, 60, 65, 80, 45, 70, ST_WHITE);
  tft.setTextColor(ST_MUTED, ST_PANEL);
  tft.setTextSize(1);
  tft.drawString("PREVIOUS", 30, 94);

  tft.fillRect(113, 32, 94, 78, ST_PANEL);
  tft.drawRoundRect(113, 32, 94, 78, 4, ST_ACCENT);
  tft.fillTriangle(145, 58, 145, 82, 170, 70, ST_ACCENT);
  tft.setTextColor(ST_WHITE, ST_PANEL);
  tft.setTextSize(1);
  tft.drawString("PLAY / PAUSE", 124, 94);

  tft.fillRect(216, 32, 94, 78, ST_PANEL);
  tft.drawRoundRect(216, 32, 94, 78, 4, ST_BORDER);
  tft.fillTriangle(245, 60, 245, 80, 265, 70, ST_WHITE);
  tft.fillTriangle(265, 60, 265, 80, 285, 70, ST_WHITE);
  tft.setTextColor(ST_MUTED, ST_PANEL);
  tft.setTextSize(1);
  tft.drawString("NEXT", 250, 94);

  // Row 2: VOL -, MUTE, VOL +
  tft.fillRect(10, 118, 94, 78, ST_PANEL);
  tft.drawRoundRect(10, 118, 94, 78, 4, ST_BORDER);
  tft.fillRect(38, 150, 38, 6, ST_WHITE);
  tft.setTextColor(ST_MUTED, ST_PANEL);
  tft.setTextSize(1);
  tft.drawString("VOL -", 40, 178);

  tft.fillRect(113, 118, 94, 78, isMuted ? ST_RED : ST_PANEL);
  tft.drawRoundRect(113, 118, 94, 78, 4, isMuted ? ST_RED : ST_BORDER);
  tft.fillRect(145, 142, 12, 22, ST_WHITE);
  tft.fillTriangle(157, 142, 157, 164, 175, 174, ST_WHITE);
  tft.setTextColor(isMuted ? ST_WHITE : ST_MUTED, isMuted ? ST_RED : ST_PANEL);
  tft.setTextSize(1);
  tft.drawString(isMuted ? "MUTED" : "MUTE", 143, 178);

  tft.fillRect(216, 118, 94, 78, ST_PANEL);
  tft.drawRoundRect(216, 118, 94, 78, 4, ST_BORDER);
  tft.fillRect(244, 150, 38, 6, ST_WHITE);
  tft.fillRect(260, 134, 6, 38, ST_WHITE);
  tft.setTextColor(ST_MUTED, ST_PANEL);
  tft.setTextSize(1);
  tft.drawString("VOL +", 248, 178);
}

// -------------------------------------------------------------
// TAB 1: EXECUTIVE LAUNCHER DECK
// -------------------------------------------------------------
void drawLauncherPage() {
  tft.fillRect(0, 25, 320, 178, ST_BG);

  // Button 1: TABFORGE STUDIO
  tft.fillRect(10, 32, 94, 78, ST_PANEL);
  tft.drawRoundRect(10, 32, 94, 78, 4, ST_GOLD);
  tft.fillRect(36, 48, 42, 22, ST_GOLD);
  tft.setTextColor(ST_BG, ST_GOLD);
  tft.setTextSize(2);
  tft.drawString("TF", 46, 52);
  tft.setTextColor(ST_WHITE, ST_PANEL);
  tft.setTextSize(1);
  tft.drawString("TABFORGE", 26, 85);

  // Button 2: AGY AI AGENT
  tft.fillRect(113, 32, 94, 78, ST_PANEL);
  tft.drawRoundRect(113, 32, 94, 78, 4, ST_ACCENT);
  tft.fillRect(138, 48, 44, 22, ST_ACCENT);
  tft.setTextColor(ST_BG, ST_ACCENT);
  tft.setTextSize(2);
  tft.drawString("AGY", 142, 52);
  tft.setTextColor(ST_WHITE, ST_PANEL);
  tft.setTextSize(1);
  tft.drawString("AGY AGENT", 130, 85);

  // Button 3: TERMINAL (>_)
  tft.fillRect(216, 32, 94, 78, ST_PANEL);
  tft.drawRoundRect(216, 32, 94, 78, 4, ST_BORDER);
  tft.setTextColor(ST_WHITE, ST_PANEL);
  tft.setTextSize(2);
  tft.drawString(">_", 252, 50);
  tft.setTextSize(1);
  tft.setTextColor(ST_MUTED, ST_PANEL);
  tft.drawString("TERMINAL", 232, 85);

  // Button 4: GOOGLE
  tft.fillRect(10, 118, 94, 78, ST_PANEL);
  tft.drawRoundRect(10, 118, 94, 78, 4, ST_BORDER);
  tft.drawCircle(57, 146, 12, ST_WHITE);
  tft.drawLine(50, 146, 64, 146, ST_WHITE);
  tft.setTextColor(ST_MUTED, ST_PANEL);
  tft.setTextSize(1);
  tft.drawString("BROWSER", 34, 172);

  // Button 5: LOCK PC
  tft.fillRect(113, 118, 94, 78, ST_PANEL);
  tft.drawRoundRect(113, 118, 94, 78, 4, ST_RED);
  tft.drawRoundRect(149, 140, 22, 16, 2, ST_RED);
  tft.drawCircle(160, 136, 6, ST_RED);
  tft.setTextColor(ST_WHITE, ST_PANEL);
  tft.setTextSize(1);
  tft.drawString("LOCK PC", 133, 172);

  // Button 6: FILES (FILE EXPLORER)
  tft.fillRect(216, 118, 94, 78, ST_PANEL);
  tft.drawRoundRect(216, 118, 94, 78, 4, ST_BORDER);
  tft.fillRect(248, 142, 30, 18, ST_WHITE);
  tft.fillRect(248, 138, 12, 5, ST_WHITE);
  tft.setTextColor(ST_MUTED, ST_PANEL);
  tft.setTextSize(1);
  tft.drawString("FILES", 246, 172);
}

// -------------------------------------------------------------
// TAB 2: PRO MONITOR HUB (MINIMALIST MATTE SLATE)
// -------------------------------------------------------------
void drawMonitorStaticFrame() {
  tft.fillRect(0, 25, 320, 178, ST_BG);

  // Sub-Mode Header Selector
  tft.fillRect(6, 28, 308, 22, ST_PANEL);
  tft.drawRoundRect(6, 28, 308, 22, 2, ST_BORDER);
  
  tft.setTextColor(ST_WHITE, ST_PANEL);
  tft.setTextSize(1);
  tft.drawString(monitorSubMode == 0 ? "[ OVERVIEW ]" : "  OVERVIEW  ", 14, 34);
  tft.drawString(monitorSubMode == 1 ? "[ NETWORK/DISK ]" : "  NETWORK/DISK  ", 110, 34);
  tft.drawString(monitorSubMode == 2 ? "[ HISTOGRAMS ]" : "  HISTOGRAMS  ", 220, 34);

  if (monitorSubMode == 0) {
    tft.fillRect(6, 54, 148, 65, ST_PANEL);
    tft.drawRoundRect(6, 54, 148, 65, 3, ST_BORDER);
    tft.setTextColor(ST_MUTED, ST_PANEL);
    tft.drawString("CPU LOAD / CLOCK", 14, 60);

    tft.fillRect(166, 54, 148, 65, ST_PANEL);
    tft.drawRoundRect(166, 54, 148, 65, 3, (cpuTemp > 75) ? ST_RED : ST_BORDER);
    tft.setTextColor(ST_MUTED, ST_PANEL);
    tft.drawString("CPU TEMP / UPTIME", 174, 60);

    tft.fillRect(6, 123, 308, 14, ST_PANEL);
    tft.drawRoundRect(6, 123, 308, 14, 2, ST_BORDER);

    tft.fillRect(6, 141, 308, 58, ST_PANEL);
    tft.drawRoundRect(6, 141, 308, 58, 3, ST_BORDER);
    tft.setTextColor(ST_MUTED, ST_PANEL);
    tft.drawString("CPU LOAD WATERFALL GRAPH", 14, 145);
  }
  else if (monitorSubMode == 1) {
    tft.fillRect(6, 54, 308, 68, ST_PANEL);
    tft.drawRoundRect(6, 54, 308, 68, 3, ST_BORDER);
    tft.setTextColor(ST_MUTED, ST_PANEL);
    tft.drawString("LIVE NETWORK BANDWIDTH", 14, 60);
    tft.setTextColor(ST_WHITE, ST_PANEL);
    tft.drawString("DOWNLOAD (DL):", 14, 78);
    tft.drawString("UPLOAD (UL):", 175, 78);

    tft.fillRect(6, 126, 308, 72, ST_PANEL);
    tft.drawRoundRect(6, 126, 308, 72, 3, ST_BORDER);
    tft.setTextColor(ST_MUTED, ST_PANEL);
    tft.drawString("PRIMARY DISK DRIVE STORAGE", 14, 132);

    tft.fillRect(14, 172, 290, 16, ST_BG);
    tft.drawRoundRect(14, 172, 290, 16, 2, ST_BORDER);
  }
  else if (monitorSubMode == 2) {
    tft.fillRect(6, 54, 148, 144, ST_PANEL);
    tft.drawRoundRect(6, 54, 148, 144, 3, ST_BORDER);
    tft.setTextColor(ST_MUTED, ST_PANEL);
    tft.drawString("CPU HISTOGRAM", 12, 60);

    tft.fillRect(166, 54, 148, 144, ST_PANEL);
    tft.drawRoundRect(166, 54, 148, 144, 3, ST_BORDER);
    tft.setTextColor(ST_MUTED, ST_PANEL);
    tft.drawString("RAM HISTOGRAM", 172, 60);
  }
}

void updateMonitorTelemetryValues() {
  if (monitorSubMode == 0) {
    tft.setTextColor(ST_WHITE, ST_PANEL);
    tft.setTextSize(2);
    char cStr[16]; snprintf(cStr, sizeof(cStr), "%d%%   ", cpuUsage);
    tft.drawString(cStr, 14, 76);

    tft.setTextSize(1);
    tft.setTextColor(ST_ACCENT, ST_PANEL);
    char fStr[16]; snprintf(fStr, sizeof(fStr), "%.2f GHz ", cpuFreq);
    tft.drawString(fStr, 80, 82);

    tft.setTextColor((cpuTemp > 75) ? ST_RED : ST_WHITE, ST_PANEL);
    tft.setTextSize(2);
    char tStr[16]; snprintf(tStr, sizeof(tStr), "%d C  ", cpuTemp);
    tft.drawString(tStr, 174, 76);

    tft.setTextSize(1);
    tft.setTextColor(ST_MUTED, ST_PANEL);
    char uStr[16]; snprintf(uStr, sizeof(uStr), "UP:%dh%dm ", uptimeMins/60, uptimeMins%60);
    tft.drawString(uStr, 235, 82);

    tft.fillRect(8, 125, 304, 10, ST_PANEL);
    int ramW = (304 * ramUsage) / 100;
    if (ramW > 0) tft.fillRect(8, 125, ramW, 10, ST_ACCENT);

    tft.fillRect(14, 156, 290, 38, ST_PANEL);
    for (int i = 0; i < 20; i++) {
      int barH = min(36, (int)(cpuHistory[i] * 0.36));
      int x = 14 + (i * 14);
      int y = 194 - barH;
      uint16_t col = (cpuHistory[i] > 80) ? ST_RED : ((cpuHistory[i] > 40) ? ST_GOLD : ST_ACCENT);
      if (barH > 0) tft.fillRect(x, y, 11, barH, col);
    }
  }
  else if (monitorSubMode == 1) {
    tft.setTextColor(ST_ACCENT, ST_PANEL);
    tft.setTextSize(2);
    char dlStr[24]; snprintf(dlStr, sizeof(dlStr), "%d KB/s    ", dlSpeed);
    tft.drawString(dlStr, 14, 92);

    tft.setTextColor(ST_WHITE, ST_PANEL);
    char ulStr[24]; snprintf(ulStr, sizeof(ulStr), "%d KB/s    ", ulSpeed);
    tft.drawString(ulStr, 175, 92);

    tft.setTextColor(ST_WHITE, ST_PANEL);
    char diskStr[24]; snprintf(diskStr, sizeof(diskStr), "USED: %d%%  ", diskUsage);
    tft.drawString(diskStr, 14, 148);

    tft.fillRect(16, 174, 286, 12, ST_BG);
    int dW = (286 * diskUsage) / 100;
    if (dW > 0) tft.fillRect(16, 174, dW, 12, ST_ACCENT);
  }
  else if (monitorSubMode == 2) {
    tft.fillRect(12, 74, 136, 120, ST_PANEL);
    for (int i = 0; i < 18; i++) {
      int barH = min(110, (int)(cpuHistory[i] * 1.1));
      int x = 12 + (i * 7);
      int y = 192 - barH;
      uint16_t col = (cpuHistory[i] > 80) ? ST_RED : ((cpuHistory[i] > 40) ? ST_GOLD : ST_ACCENT);
      if (barH > 0) tft.fillRect(x, y, 5, barH, col);
    }

    tft.fillRect(172, 74, 136, 120, ST_PANEL);
    for (int i = 0; i < 18; i++) {
      int barH = min(110, (int)(ramHistory[i] * 1.1));
      int x = 172 + (i * 7);
      int y = 192 - barH;
      uint16_t col = (ramHistory[i] > 80) ? ST_RED : ((ramHistory[i] > 40) ? ST_GOLD : ST_WHITE);
      if (barH > 0) tft.fillRect(x, y, 5, barH, col);
    }
  }
}

void parseSerialTelemetry(String line) {
  if (line.startsWith("STATS:")) {
    int p1 = line.indexOf(':', 6);
    int p2 = line.indexOf(':', p1 + 1);
    int p3 = line.indexOf(':', p2 + 1);
    int p4 = line.indexOf(':', p3 + 1);
    int p5 = line.indexOf(':', p4 + 1);
    int p6 = line.indexOf(':', p5 + 1);
    int p7 = line.indexOf(':', p6 + 1);
    int p8 = line.indexOf(':', p7 + 1);
    int p9 = line.indexOf(':', p8 + 1);

    if (p1 > 0 && p2 > 0 && p3 > 0 && p4 > 0) {
      cpuUsage = line.substring(6, p1).toInt();
      ramUsage = line.substring(p1 + 1, p2).toInt();
      gpuUsage = line.substring(p2 + 1, p3).toInt();
      cpuTemp = line.substring(p3 + 1, p4).toInt();

      if (p5 > 0) isMuted = (line.substring(p4 + 1, p5).toInt() == 1);
      if (p6 > 0) dlSpeed = line.substring(p5 + 1, p6).toInt();
      if (p7 > 0) ulSpeed = line.substring(p6 + 1, p7).toInt();
      if (p8 > 0) diskUsage = line.substring(p7 + 1, p8).toInt();
      if (p9 > 0) {
        cpuFreq = line.substring(p8 + 1, p9).toFloat();
        uptimeMins = line.substring(p9 + 1).toInt();
      }

      isConnected = true;
      lastTelemetryRx = millis();

      for (int i = 0; i < 19; i++) {
        cpuHistory[i] = cpuHistory[i + 1];
        ramHistory[i] = ramHistory[i + 1];
      }
      cpuHistory[19] = cpuUsage;
      ramHistory[19] = ramUsage;

      if (currentTab == 2) updateMonitorTelemetryValues();
    }
  }
}

void sendCommandToPc(String cmd) {
  Serial.println("CMD:" + cmd);
}

void switchTab(int newTab) {
  currentTab = newTab;
  drawTabs();
  if (currentTab == 0) drawMusicPage();
  else if (currentTab == 1) drawLauncherPage();
  else if (currentTab == 2) {
    drawMonitorStaticFrame();
    updateMonitorTelemetryValues();
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(CYD_BACKLIGHT_PIN, OUTPUT);
  digitalWrite(CYD_BACKLIGHT_PIN, HIGH);
  analogReadResolution(12);

  tft.init();
  tft.setRotation(1);
  tft.fillScreen(ST_BG);

  // Dedicated Touch SPI bus init
  touchSPI.begin(XPT2046_CLK, XPT2046_MISO, XPT2046_MOSI, XPT2046_CS);
  touch.begin(touchSPI);
  touch.setRotation(1);

  drawHeaderBackground();
  drawTabs();
  drawMusicPage();
}

void loop() {
  if (Serial.available()) {
    String line = Serial.readStringUntil('\n');
    line.trim();
    parseSerialTelemetry(line);
  }

  if (isConnected && millis() - lastTelemetryRx > 4000) {
    isConnected = false;
    drawHeaderBackground();
  }

  if (touch.touched()) {
    TS_Point p = touch.getPoint();
    if (p.z > 50) {
      int tX = constrain(map(p.x, 350, 3700, 0, 320), 0, 320);
      int tY = constrain(map(p.y, 350, 3700, 0, 240), 0, 240);

      // Bottom Tabs Area (Y > 200)
      if (tY > 200) {
        if (tX < 105 && currentTab != 0) switchTab(0);
        else if (tX >= 105 && tX < 212 && currentTab != 1) switchTab(1);
        else if (tX >= 212 && currentTab != 2) switchTab(2);
        delay(250);
      }
      // Tab 0: Music Page
      else if (currentTab == 0 && tY >= 32 && tY <= 196) {
        if (tY <= 110) {
          if (tX >= 10 && tX <= 104) { sendCommandToPc("PREV"); }
          else if (tX >= 113 && tX <= 207) { sendCommandToPc("PLAY_PAUSE"); }
          else if (tX >= 216 && tX <= 310) { sendCommandToPc("NEXT"); }
        } else {
          if (tX >= 10 && tX <= 104) { sendCommandToPc("VOL_DOWN"); }
          else if (tX >= 113 && tX <= 207) { sendCommandToPc("MUTE"); isMuted = !isMuted; drawMusicPage(); }
          else if (tX >= 216 && tX <= 310) { sendCommandToPc("VOL_UP"); }
        }
        delay(200);
      }
      // Tab 1: Launcher Page (TABFORGE, AGY, TERMINAL, GOOGLE, LOCK, FILES)
      else if (currentTab == 1 && tY >= 32 && tY <= 196) {
        if (tY <= 110) {
          if (tX >= 10 && tX <= 104) { sendCommandToPc("TABFORGE"); }
          else if (tX >= 113 && tX <= 207) { sendCommandToPc("AGY"); }
          else if (tX >= 216 && tX <= 310) { sendCommandToPc("TERM"); }
        } else {
          if (tX >= 10 && tX <= 104) { sendCommandToPc("GOOGLE"); }
          else if (tX >= 113 && tX <= 207) { sendCommandToPc("LOCK"); }
          else if (tX >= 216 && tX <= 310) { sendCommandToPc("FILES"); }
        }
        delay(250);
      }
      // Tab 2: Monitor Sub-Mode Switcher Bar (Y: 28 - 50)
      else if (currentTab == 2 && tY >= 28 && tY <= 50) {
        if (tX < 105) monitorSubMode = 0;
        else if (tX >= 105 && tX < 210) monitorSubMode = 1;
        else if (tX >= 210) monitorSubMode = 2;
        drawMonitorStaticFrame();
        updateMonitorTelemetryValues();
        delay(250);
      }
    }
  }

  static unsigned long lastHeaderUpdate = 0;
  if (millis() - lastHeaderUpdate > 8000) {
    lastHeaderUpdate = millis();
    drawHeaderBackground();
  }
}
