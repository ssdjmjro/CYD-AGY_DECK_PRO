# CYD AGYDeck Pro 🚀🎛️

**CYD AGYDeck Pro** is an open-source, ultra-premium Cyberpunk Touchscreen PC Stream Deck, Media Controller, Fast App Launcher, and Real-Time Hardware Telemetry Monitor built for the **Cheap Yellow Display (CYD / ESP32-2432S028)**.

![CYD AGYDeck Pro Banner](https://img.shields.io/badge/CYD-ESP32--2432S028-cyan?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-magenta?style=for-the-badge)
![Platform](https://img.shields.io/badge/Platform-Arduino%20%2F%20ESP32-green?style=for-the-badge)

---

## ✨ Features

- **🎵 Dedicated Music Deck Tab**:
  - `Play / Pause`, `Previous Track`, `Next Track`
  - `Volume Up (+5%)`, `Volume Down (-5%)`, and `Master Mute` toggle.
- **🚀 Fast App & AGY Launcher Tab**:
  - `Terminal` (>_ CLI Launcher)
  - `AGY AI Agent` (Instant `agy` terminal launch)
  - `Google` (Opens web browser)
  - `Lock PC` (Security lock session)
  - `Screenshot` (Instant screen capture)
  - `File Explorer`
- **📊 Advanced System Hardware Monitor Tab**:
  - Real-Time **CPU Load %**, **CPU Temperature °C**, **RAM Usage %**, and **GPU Load %**.
  - **Network Bandwidth Speedometer**: Live **Download (`DL KB/s`)** and **Upload (`UL KB/s`)** speeds.
  - **Primary Disk Storage Gauge**: Space used %.
  - **CPU Clock Speed**: Real-time frequency in GHz.
  - **System Uptime**: Live hours & minutes counter.
  - **3 Sub-Modes**: `Overview Gauges`, `Net & Disk Analytics`, and `Dual Waterfall Load Graphs`.
- **🔋 LiPo Battery HUD**: Monitored on GPIO 34 (Voltage & Percentage).
- **💾 MicroSD Card Launcher Support**: Pre-compiled `.bin` payload ready for ESP32 Firmware Launcher.

---

## 🛠️ Hardware Requirements

- **Cheap Yellow Display (CYD)**: ESP32-2432S028 / 2432S028C (2.8" ILI9341 LCD + XPT2046 Resistive Touch).
- **USB-C Cable** (or Micro-USB depending on board revision).
- **Optional**: 3.7V LiPo Battery (JST connector).

---

## 📁 Repository Structure

```text
CYD-AGYDeck-Pro/
├── README.md                          # Documentation & Setup Guide
├── LICENSE                            # MIT License
├── firmware/
│   └── CYD_PC_StreamDeck/
│       └── CYD_PC_StreamDeck.ino      # ESP32 Arduino Firmware Source
├── bin/
│   └── CYD_StreamDeck_SD.bin          # Compiled MicroSD Payload Binary
├── companion/
│   ├── cyd_pc_companion.py            # Python PC Telemetry & Action Daemon
│   └── requirements.txt               # Python Dependencies (pyserial, psutil)
└── scripts/
    ├── flash.sh                       # One-Click Firmware Flashing Script
    └── run_companion.sh               # One-Click PC Companion Daemon Script
```

---

## 🚀 Quick Setup & Installation

### Option 1: Direct Flash to CYD Board (Linux / Mac / WSL)

1. Connect your CYD board to your computer via USB.
2. Run the flashing script:

```bash
chmod +x scripts/flash.sh
./scripts/flash.sh
```

### Option 2: Load via MicroSD Card (ESP32 Launcher)

1. Copy `bin/CYD_StreamDeck_SD.bin` onto your FAT32 MicroSD card.
2. Insert MicroSD into CYD board.
3. Power on -> Boot into **ESP32 Launcher** -> Select `CYD_StreamDeck_SD.bin` -> **Install / Run**.

---

## 🖥️ Running the PC Companion Daemon

To stream live CPU/RAM/Network stats to CYD and receive Stream Deck touch commands:

1. Install Python dependencies:

```bash
pip install -r companion/requirements.txt
```

2. Run the companion script:

```bash
chmod +x scripts/run_companion.sh
./scripts/run_companion.sh
```

---

## ⚙️ Pinout Configuration Reference

| Feature | ESP32 GPIO Pin |
|---|---|
| LCD Display Driver | ILI9341 (SPI 13, 12, 14, 15, DC 2, RST 4) |
| LCD Backlight | GPIO 21 (HIGH) |
| Touchscreen Controller | XPT2046 (VSPI: CLK 25, MISO 39, MOSI 32, CS 33, IRQ 36) |
| Audio Speaker Output | GPIO 26 |
| LiPo Battery ADC | GPIO 34 |

---

## 📄 License

Distributed under the **MIT License**. See `LICENSE` for details.
