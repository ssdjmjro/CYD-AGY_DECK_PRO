#!/usr/bin/env bash
# One-Click Companion Daemon Runner for CYD AGYDeck Pro

SCRIPT_DIR="$(dirname "$0")"
COMPANION_DIR="$SCRIPT_DIR/../companion"

echo "=== Launching CYD AGYDeck Pro Companion Daemon ==="
pip install -r "$COMPANION_DIR/requirements.txt" > /dev/null 2>&1
python3 "$COMPANION_DIR/cyd_pc_companion.py"
