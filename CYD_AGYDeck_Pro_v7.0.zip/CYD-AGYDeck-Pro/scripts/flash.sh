#!/usr/bin/env bash
# BULLETPROOF ONE-CLICK FIRMWARE FLASHER FOR CYD AGYDECK PRO

echo "=== CYD AGYDeck Pro Auto-Flasher ==="

# 1. Auto-detect Serial Port (/dev/ttyUSB* or /dev/ttyACM*)
PORT=""
for p in /dev/ttyUSB0 /dev/ttyUSB1 /dev/ttyACM0 /dev/ttyACM1; do
    if [ -e "$p" ]; then
        PORT="$p"
        break
    fi
done

if [ -z "$PORT" ]; then
    echo "❌ Error: No CYD board detected on USB ports!"
    echo "Please make sure your CYD board is connected via USB cable."
    exit 1
fi

echo "✅ Found CYD Board on Port: $PORT"

# 2. Fix Port Permissions if needed
sudo chmod 666 "$PORT" 2>/dev/null || true

# 3. Ensure esptool is installed
if ! python3 -c "import esptool" 2>/dev/null; then
    echo "[*] Installing esptool flasher library..."
    pip3 install esptool pyserial psutil > /dev/null 2>&1 || pip install esptool pyserial psutil > /dev/null 2>&1
fi

BIN_PATH="$(dirname "$0")/../bin/CYD_StreamDeck_SD.bin"

if [ ! -f "$BIN_PATH" ]; then
    echo "❌ Error: Binary payload file not found at $BIN_PATH!"
    exit 1
fi

echo "[*] Flashing binary to CYD board at 460800 baud..."
python3 -m esptool --port "$PORT" --baud 460800 write_flash -z 0x10000 "$BIN_PATH"

if [ $? -eq 0 ]; then
    echo "🎉 FLASH SUCCESSFUL! CYD board reset and running AGYDeck Pro!"
else
    echo "⚠️ Flashing at 460800 baud failed. Retrying at 115200 baud..."
    python3 -m esptool --port "$PORT" --baud 115200 write_flash -z 0x10000 "$BIN_PATH"
fi
